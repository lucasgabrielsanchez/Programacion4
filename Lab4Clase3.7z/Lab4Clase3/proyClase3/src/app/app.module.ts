import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgModel } from '@angular/forms';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { MostrarDatoComponent } from './mostrar-dato/mostrar-dato.component';
import { EnviarDatoComponent } from './enviar-dato/enviar-dato.component';

@NgModule({
  declarations: [
    AppComponent,
    MostrarDatoComponent,
    EnviarDatoComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
