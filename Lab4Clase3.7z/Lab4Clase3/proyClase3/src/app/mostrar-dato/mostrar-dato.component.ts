import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-mostrar-dato',
  templateUrl: './mostrar-dato.component.html',
  styleUrls: ['./mostrar-dato.component.css']
})
export class MostrarDatoComponent implements OnInit {

  @Input() Dato: any;

  @Input() Listado: any;

  constructor() { }

  ngOnInit() {
  }

}
