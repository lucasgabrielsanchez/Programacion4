import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-enviar-dato',
  templateUrl: './enviar-dato.component.html',
  styleUrls: ['./enviar-dato.component.css']
})
export class EnviarDatoComponent implements OnInit {

  @Output() enviarDato: EventEmitter<any> = new EventEmitter<any>();

  palabraIngresada: any;

  constructor() { }

  enviar()
  {
    //alert('hola enviar dato');
    this.enviarDato.emit('evento enviar dato');
  }

  enviar2()
  {
    //alert('hola enviar dato');
    this.enviarDato.emit(this.palabraIngresada);
  }

  ngOnInit() {
  }

}
