export class Fruta {

    constructor(
        public nombre:String,
        public color:String,
        public madura:Boolean
    ){}
      
}