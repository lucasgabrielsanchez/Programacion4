export class Coche {

    constructor(
        public nombre:String,
        public caballaje:String,
        public color:String
    ) {}
}