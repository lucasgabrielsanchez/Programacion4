//////////Clase 2
export class Persona {

    public nombre:String;
    public apellido:String;
    public dni:string;

    constructor()
    {}

    Guardar()
    {
        localStorage.setItem("personita", JSON.stringify(this));
        //console.info(this);
    }

    Traer()
    {    
        alert(localStorage.getItem("personita"));
        //como armarlo como objeto JSON.parse(localStorage.getItem("personita"))
    }
      
}