import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BindingClase2Component } from './binding-clase2.component';

describe('BindingClase2Component', () => {
  let component: BindingClase2Component;
  let fixture: ComponentFixture<BindingClase2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BindingClase2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BindingClase2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
