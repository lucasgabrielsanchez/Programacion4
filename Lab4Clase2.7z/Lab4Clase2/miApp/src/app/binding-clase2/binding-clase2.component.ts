import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding-clase2',
  templateUrl: './binding-clase2.component.html',
  styleUrls: ['./binding-clase2.component.css']
})
export class BindingClase2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
