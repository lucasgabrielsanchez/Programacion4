export class Empleado {

    constructor(
        public nombre:String,
        public edad:Number,
        public cargo:String,
        public contratado:Boolean 
    ){}
      
}