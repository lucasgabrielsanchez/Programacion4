import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ErrorComponent } from '../error/error.component';
import { LoginComponent } from '../login/login.component';
import { RouterModule, Routes } from '@angular/router';

const MiRuteo = [
  { path: '' , component: LoginComponent},
  { path: 'Error', component: ErrorComponent },
  { path: '**', component: ErrorComponent },
  { path: 'error', component: ErrorComponent }
];


@NgModule({
  imports: [
    RouterModule.forRoot(MiRuteo)
  ],
  exports: [
    RouterModule
  ],
  declarations: []
})
export class RuteandoModule { }
