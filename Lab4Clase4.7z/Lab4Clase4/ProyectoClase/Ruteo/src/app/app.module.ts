import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgModel, FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';

import { LoginComponent } from '../login/login.component';

import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from '../error/error.component';

import { RuteandoModule } from '../ruteando/ruteando.module';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RuteandoModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
